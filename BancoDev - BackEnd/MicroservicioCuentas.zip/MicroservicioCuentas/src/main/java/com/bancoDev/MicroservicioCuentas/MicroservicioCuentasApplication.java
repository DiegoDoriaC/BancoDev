package com.bancoDev.MicroservicioCuentas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioCuentasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioCuentasApplication.class, args);
	}

}
