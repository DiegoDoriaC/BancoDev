package com.bancoDev.MicroservicioCuentas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioCuentasApplicationTests {

	@Test
	void contextLoads() {
	}

}
