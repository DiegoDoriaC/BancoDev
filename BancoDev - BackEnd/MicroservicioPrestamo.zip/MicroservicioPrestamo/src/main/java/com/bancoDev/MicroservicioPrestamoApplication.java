package com.bancoDev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioPrestamoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioPrestamoApplication.class, args);
	}

}
