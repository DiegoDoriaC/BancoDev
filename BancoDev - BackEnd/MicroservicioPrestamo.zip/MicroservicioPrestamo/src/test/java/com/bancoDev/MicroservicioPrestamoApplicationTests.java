package com.bancoDev;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioPrestamoApplicationTests {

	@Test
	void contextLoads() {
	}

}
